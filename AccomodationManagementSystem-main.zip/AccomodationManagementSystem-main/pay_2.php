<?php
header('Location:pay_2.html');
?>
