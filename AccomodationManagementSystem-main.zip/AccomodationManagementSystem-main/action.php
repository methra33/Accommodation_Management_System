
<?
if ($_POST['submitUrl']){
header('Location:'.$_POST['url']);
}
?>
